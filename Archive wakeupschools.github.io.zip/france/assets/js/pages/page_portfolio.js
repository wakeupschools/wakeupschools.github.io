var PortfolioPage = function () {


    return {

        init: function () {
            $('.sorting-grid').mixitup();
        }

    };

}();